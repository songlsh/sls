package com.zheng.common.base;

/**
 * 全局常量
 * Created by shuzheng on 2017/2/18.
 */
public class BaseConstants {


}
