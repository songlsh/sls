package com.zheng.cms.rpc.api;

import com.zheng.common.base.BaseService;
import com.zheng.cms.dao.model.CmsCategory;
import com.zheng.cms.dao.model.CmsCategoryExample;

/**
* CmsCategoryService接口
* Created by shuzheng on 2017/4/5.
*/
public interface CmsCategoryService extends BaseService<CmsCategory, CmsCategoryExample> {

}