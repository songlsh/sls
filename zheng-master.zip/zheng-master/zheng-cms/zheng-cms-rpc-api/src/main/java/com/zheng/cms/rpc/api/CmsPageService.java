package com.zheng.cms.rpc.api;

import com.zheng.common.base.BaseService;
import com.zheng.cms.dao.model.CmsPage;
import com.zheng.cms.dao.model.CmsPageExample;

/**
* CmsPageService接口
* Created by shuzheng on 2017/4/5.
*/
public interface CmsPageService extends BaseService<CmsPage, CmsPageExample> {

}