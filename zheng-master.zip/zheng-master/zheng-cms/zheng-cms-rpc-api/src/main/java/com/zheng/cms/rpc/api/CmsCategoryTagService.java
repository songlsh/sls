package com.zheng.cms.rpc.api;

import com.zheng.common.base.BaseService;
import com.zheng.cms.dao.model.CmsCategoryTag;
import com.zheng.cms.dao.model.CmsCategoryTagExample;

/**
* CmsCategoryTagService接口
* Created by shuzheng on 2017/4/5.
*/
public interface CmsCategoryTagService extends BaseService<CmsCategoryTag, CmsCategoryTagExample> {

}