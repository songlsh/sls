package com.zheng.cms.rpc.api;

import com.zheng.common.base.BaseService;
import com.zheng.cms.dao.model.CmsTopic;
import com.zheng.cms.dao.model.CmsTopicExample;

/**
* CmsTopicService接口
* Created by shuzheng on 2017/4/5.
*/
public interface CmsTopicService extends BaseService<CmsTopic, CmsTopicExample> {

}