package com.zheng.cms.rpc.api;

import com.zheng.common.base.BaseService;
import com.zheng.cms.dao.model.CmsTag;
import com.zheng.cms.dao.model.CmsTagExample;

/**
* CmsTagService接口
* Created by shuzheng on 2017/4/5.
*/
public interface CmsTagService extends BaseService<CmsTag, CmsTagExample> {

}