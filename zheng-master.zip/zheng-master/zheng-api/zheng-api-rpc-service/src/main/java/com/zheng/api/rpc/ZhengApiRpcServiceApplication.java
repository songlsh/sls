package com.zheng.api.rpc;

/**
 * 服务启动类
 * Created by shuzheng on 2017/2/19.
 */
public class ZhengApiRpcServiceApplication {

    public static void main(String[] args) {
        com.alibaba.dubbo.container.Main.main(args);
    }
}
