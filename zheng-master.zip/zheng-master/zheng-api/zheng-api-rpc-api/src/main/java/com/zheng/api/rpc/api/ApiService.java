package com.zheng.api.rpc.api;

/**
 * api系统总接口
 * Created by shuzheng on 2017/2/19.
 */
public interface ApiService {

    /**
     * hello
     * @param name
     * @return
     */
    String hello(String name);

}
