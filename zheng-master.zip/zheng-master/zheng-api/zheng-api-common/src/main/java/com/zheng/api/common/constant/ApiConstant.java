package com.zheng.api.common.constant;

import com.zheng.common.base.BaseConstants;

/**
 * api系统常量类
 * Created by shuzheng on 2017/2/19.
 */
public class ApiConstant extends BaseConstants {
}
